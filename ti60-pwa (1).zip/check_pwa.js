// 校验 PWA 离线包完整性：sw.js 预缓存清单里每个文件都必须真实存在，
// 少一个 cache.addAll() 整体失败 → Service Worker 装上但什么都没缓存。
const fs = require('fs');
const path = require('path');

const ROOT = process.argv[2] || '.';
const sw = fs.readFileSync(path.join(ROOT, 'sw.js'), 'utf8');

const shellBlock = sw.match(/const SHELL = \[([\s\S]*?)\];/);
if (!shellBlock) { console.error('FAIL 找不到 SHELL 列表'); process.exit(1); }

const entries = [...shellBlock[1].matchAll(/'([^']+)'/g)].map(m => m[1]);
let missing = 0;
console.log(`预缓存清单：${entries.length} 项`);
for (const e of entries) {
  const rel = e.replace(/^\.\//, '');
  if (rel === '' || rel.endsWith('/')) { console.log(`  = ${e}（目录，跳过）`); continue; }
  const p = path.join(ROOT, rel);
  const ok = fs.existsSync(p) && fs.statSync(p).isFile();
  if (!ok) missing++;
  console.log(`  ${ok ? 'OK ' : 'MISS'} ${e}${ok ? '  ' + fs.statSync(p).size + ' B' : ''}`);
}

// manifest 校验
for (const mf of ['manifest.webmanifest', 'manifest-mobile.webmanifest']) {
  const p = path.join(ROOT, mf);
  if (!fs.existsSync(p)) { console.log(`MISS ${mf}`); missing++; continue; }
  try {
    const j = JSON.parse(fs.readFileSync(p, 'utf8'));
    const bad = [];
    for (const ic of j.icons || []) {
      const ip = path.join(ROOT, ic.src);
      if (!fs.existsSync(ip)) bad.push(ic.src);
    }
    console.log(`${bad.length ? 'WARN' : 'OK  '} ${mf}  name="${j.name}" start="${j.start_url}" display=${j.display}`
      + (bad.length ? `  缺图标: ${bad.join(', ')}` : ''));
    if (bad.length) missing++;
  } catch (e) {
    console.log(`FAIL ${mf} JSON 解析失败: ${e.message}`);
    missing++;
  }
}

console.log(missing === 0 ? '\nPASS：离线包完整，可以发布' : `\nFAIL：有 ${missing} 处问题`);
process.exit(missing === 0 ? 0 : 1);
