# Ti60 蓝牙控制台 · 手机离线部署说明

> 目标：**现场不带电脑、不开服务器**，手机上直接连板子。
> 这个目录（`ti60-pwa/`）就是完整可发布的静态站点，201 KB，14 个文件。

---

## 0. 先说清楚：为什么必须选一条路

Web Bluetooth 只在**安全上下文**里可用，而 Service Worker（离线缓存 / 装成 App）
在 Chrome 里**只允许 https 与 localhost**。两条硬限制叠在一起，只有下面两种做法：

| 做法 | 需要服务器吗 | 能连蓝牙 | 能装成 App / 离线 | 适合 |
|---|---|---|---|---|
| **A. 传到任意 HTTPS 静态托管** | 不需要（托管方是云，不是你的电脑） | ✅ | ✅ | 推荐，一次配置长期用 |
| **B. 文件直接放手机，用 `file://` 打开** | 不需要 | ✅ | ❌ 装不成 | 现场断网又不想配置时的后备 |

> ⚠️ 两种都**不要**用「电脑开 http://192.168.x.x:8000」那套：不是安全上下文，
> 蓝牙会被浏览器直接禁用（页面会弹红色警告）。

**实测记录**（Chrome 129，`isSecureContext` 直接读出来）：

```
file://  → isSecureContext = true ，navigator.bluetooth = present
           → Service Worker 注册失败：URL protocol of the current origin ('file://') is not supported
http://  → isSecureContext = false（局域网 IP）
https:// → isSecureContext = true ，SW 可注册
```

---

## A. HTTPS 托管 + 装成 PWA（推荐）

装好之后：**手机主屏上有个图标，点开就是全屏 App，断网也能用**（页面走手机本地缓存，
蓝牙是本地协议，根本不需要网络）。

### A-1 用 GitHub Pages（手机上就能全部完成）

1. 手机浏览器打开 `github.com`，登录，新建一个 **Public** 仓库，例如 `ti60-console`。
2. 进仓库 → **Add file → Upload files** → 选中本目录**全部文件**（`icons` 文件夹要一起传，
   保持 `icons/` 这一层，不要摊平）。
3. 仓库 → **Settings → Pages** → Source 选 `Deploy from a branch`，
   Branch 选 `main`、目录选 `/ (root)` → Save。
4. 等 1 分钟左右，地址是 `https://<你的用户名>.github.io/ti60-console/`。
   手机用 Chrome 打开这个地址。

> 也可以让电脑一次性上传（更省事），但只要传一次，之后现场就跟电脑没关系了。

### A-2 用 Netlify Drop（拖文件夹，30 秒）

手机浏览器打开 `app.netlify.com/drop`，把整个 `ti60-pwa` 文件夹传上去，
立刻得到一个 `https://xxx.netlify.app` 地址。缺点：免费版站点可能被回收，重要场合用 GitHub Pages。

### A-3 装到主屏

- **安卓 Chrome**：打开页面 → 右上角 ⋮ → **安装应用 / 添加到主屏幕**；
  或者页面右上角会自动出现「安装」按钮（代码里已接 `beforeinstallprompt`）。
- **桌面 Chrome**：地址栏右侧的安装图标。
- iPhone：Safari 不支持 Web Bluetooth，装也没用，别浪费时间。

### A-4 验证离线是否真的可用

1. 安装后**先联网打开一次**（让 Service Worker 把 14 个文件写进缓存，页面底部日志会提示
   「离线缓存已就绪」）。
2. 打开飞行模式 → 从主屏图标点开 → 页面应该正常显示。
3. 连蓝牙、切风格、拍摄，全部正常（蓝牙不经过网络）。

---

## B. 不配置托管：`file://` 直接打开（后备方案）

适合「现场完全没有网、也不想提前配置」的情况。

1. 把本目录整个拷到手机存储，例如 `Download/ti60/`。
2. **必须用 Chrome 地址栏输入路径**：
   `file:///sdcard/Download/ti60/index_mobile.html`
   （路径因手机而异，`/storage/emulated/0/Download/ti60/index_mobile.html` 也可以）
3. 打开后加到书签，下次从书签进入，就不用再输路径。

⚠️ **不要**用「文件管理器 → 用浏览器打开」：那样地址会变成 `content://...`，
不是安全上下文，蓝牙会被禁用。必须走 `file:///`。

这条路能用蓝牙，但**装不成 App、没有离线缓存**（也谈不上需要——文件本来就在手机上）。

---

## C. 改了代码之后要做什么

`sw.js` 第一行的版本号是缓存钥匙，**每次改 `app.js` / `app.css` / html 都必须改它**，
否则已装的 App 会一直用旧文件：

```js
const VERSION = 'ti60-ble-v3-offline';   // 改成 v4、v5……
```

改完重新上传，手机上打开一次，页面会自动清掉旧缓存、换成新版本
（日志会提示「检测到新版本，下次打开会生效」）。

---

## D. 自检清单（发布前跑一遍）

```bash
node check_pwa.js .        # 预缓存清单里 14 个文件是否都存在、两个 manifest 是否合法
```

本次已验证：

- 预缓存 14 项全部存在（含两个 html、两个 manifest、6 个图标）
- 两个 manifest 的 `icons[].src` 都存在
- 断网兜底页判断正确：`/index_mobile.html → index_mobile.html`，`/ → index.html`
  （旧版 `sw.js` 一律回 `index.html`，手机断网会打开桌面版，已修复）
- `app.js` / `sw.js` 语法检查通过
